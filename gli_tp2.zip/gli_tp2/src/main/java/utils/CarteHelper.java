package utils;

public class CarteHelper {
	public static int CarteWidth = 72;
	public static int CarteHeight = 96;
}
